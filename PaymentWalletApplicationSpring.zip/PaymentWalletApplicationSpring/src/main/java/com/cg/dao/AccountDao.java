package com.cg.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Repository;

import com.cg.entity.Account;
import com.cg.entity.Transaction;
import com.cg.exception.InvalidException;

@Repository("dao")
public class AccountDao implements IAccountDao {
	private Map<Integer, Account> accountEntry = new HashMap<Integer, Account>();
	private Map<Integer, ArrayList<Transaction>> allTransaction = new HashMap<Integer, ArrayList<Transaction>>();
	private ArrayList<Transaction> listOfTransactions =new ArrayList<Transaction>();
	private static int accountCounter = 1001;
	ApplicationContext ctx;
	Transaction trans;

	public AccountDao() {
		ctx = new ClassPathXmlApplicationContext("myAnnotation.xml");
	}
	
	///
	public void createAccount(Account acct) {
		acct.setBalance(1000);
		acct.setAccountId(accountCounter);
		accountEntry.put(accountCounter, acct); // add account entry to map
		System.out.println("Account is created successfully with accountId " + acct.getAccountId());
		System.out.println("Account holders name: " + acct.getHolderName());
		System.out.println("Balance: " + acct.getBalance());
		accountCounter++;
	}

	public Map<Integer, Account> displayAccountDetails() {
		return accountEntry; // show Account object after creation
	}

	public void deposit(double amount, int accID) throws InvalidException {
		Account acc = accountEntry.get(accID);
		if (acc != null) {
			double amt = acc.getBalance();
			acc.setBalance(amt + amount);
			trans = (Transaction) ctx.getBean("transaction");
			trans.setType("credit");
			trans.setAmount(amt);
			trans.setBalance(acc.getBalance());
			listOfTransactions.add(trans);
			System.out.println( "Amount deposited successful!");

		} else
			throw new InvalidException("Accound does not exists");
	}

	public double showBalance(int accountId) throws InvalidException {
		Account acct3 = accountEntry.get(accountId);
		if (acct3 != null) {
			return acct3.getBalance();
		} else {
			throw new InvalidException("Account does not exists");
		}

	}

	public void withdraw(double amount, int accId) throws InvalidException {
		Account acc = accountEntry.get(accId);
		if (acc != null) {
			double amt = acc.getBalance();
			if (amount <= amt) { // checks if amount entered by user is less then total balance

				acc.setBalance(acc.getBalance() - amount);

				trans = (Transaction) ctx.getBean("transaction");
				trans.setType("debit");
				trans.setAmount(amount);
				trans.setBalance(acc.getBalance());
				listOfTransactions.add(trans);

				} else
					throw new InvalidException("Insufficient Balance");
		} else
			throw new InvalidException("Accound does not exists");
	}

	public void showTransaction(int accountId) {
		ArrayList<Transaction> temp = allTransaction.get(accountId);
		for (Transaction transaction1 : temp) {
			System.out.println(transaction1);
		}
	}

	public void fundTransfer(int scourceAcctId, int destAcctId, double amount) throws InvalidException {
		withdraw(amount, scourceAcctId);
		deposit(amount, destAcctId);
	}

}
