package com.cg.dao;

import java.util.Map;

import com.cg.entity.Account;
import com.cg.exception.InvalidException;

public interface IAccountDao {
	public void createAccount(Account acct);
	Map<Integer, Account> displayAccountDetails();
	public void deposit(double amount, int accountId) throws InvalidException;
	public double showBalance(int accountId) throws InvalidException;
	public void withdraw(double amount, int accountId) throws InvalidException;
	public void showTransaction(int acountId);
	void fundTransfer(int scourceAcctId, int destAcctId, double amount) throws InvalidException;

}
