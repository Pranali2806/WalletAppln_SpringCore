package com.cg.ui;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Scanner;

import com.cg.entity.Account;
import com.cg.exception.InvalidException;
import com.cg.service.AccountService;
import com.cg.service.IAccountService;
import com.cg.service.ITransactionService;
import com.cg.service.TransactionService;

public class ExecutorMain {
	public static void main(String[] args) throws IOException, SQLException {
		System.out.println("Welcome to Pay App");
		Scanner sc = new Scanner(System.in);
		IAccountService ias = new AccountService();
		ITransactionService its = new TransactionService();
		
		while(true) {
			System.out.println("1.Create Account\n2.Transaction\n3.Exit");
			String choice = sc.next();
			switch(choice){
			case "1":
				// Account creation : Enter Account holder's name,Address,Mobile number
				String holderName,holderAddress,holderEmail,holderMobileNo,holderAccountId;
				while(true){
					System.out.println("Enter Holder Name:");
					holderName = sc.next();
					boolean isValidName = ias.validateHolderName(holderName);
					if(isValidName){
						break;
					} else {
						System.out.println("Name should be min of 3 characters");
					}
					}
				while(true){
				System.out.println("Enter Address:");
				holderAddress = sc.next();
				boolean isValidAddress = ias.validateHolderAddress(holderAddress);
				if(isValidAddress){
					break;
				} else {
					System.out.println("Address should be min of 3 characters");
				}
				}
				while(true) {
				System.out.println("Enter Email:");
				holderEmail = sc.next();
				boolean isValidEmail = ias.validateHolderEmail(holderEmail);
				if (isValidEmail) {
					break;
				} else {
					System.out.println("Email address is not valid (Valid format - Eg: abc@js.com)");
				}
				}
				while(true) {
					System.out.println("Enter Mobile Number:");
					holderMobileNo = sc.next();
					boolean isValidNo = ias.validateHolderMobileNo(holderMobileNo);
					if (isValidNo) {
						break;
					} else {
						System.out.println("Number should be of 10 digits and start with 0 or 91");
					}
				}
				Account acct = new Account();
				acct.setHolderName(holderName);
				acct.setHolderAddress(holderAddress);
				acct.setHolderEmail(holderEmail);
				acct.setHolderMobileNumber(Long.parseLong(holderMobileNo));
				ias.createAccount(acct); // Inserts Account entry into map
				break;
			case "2":
					// Perform Transactions
					String choiceOfTransaction;
					String amount;
					String acctId;
					String sourceAcctId;
					String destAcctId;
					System.out.println("1.Deposit\n2.Withdraw\n3.Fund transfer\n4.Show Balance\n5.Show Transactions");
					choiceOfTransaction = sc.next();

					switch(choiceOfTransaction){
						case "1":
							while(true) {
								System.out.println("Enter Account Id");
								acctId = sc.next();
								boolean isValidAcctId = its.validateAccountId(acctId);
								if (isValidAcctId) {
									break;
								} else {
									System.out.println("Invalid Account Id (Only digits are allowed)");
								}
							}
							while(true) { 
								System.out.println("Enter Amount");
								amount = sc.next();
								boolean isValidAmount = its.validateAmount(amount);
								if (isValidAmount) {
									break;
								} else {
									System.out.println("Invalid Amount (Only digits are allowed)");
								}
							}
							try {
								ias.deposit(Double.parseDouble(amount),Integer.parseInt(acctId));
							} catch (NumberFormatException e) {
								e.printStackTrace();
							} catch (InvalidException e) {
								System.out.println(e.getMessage());
							}
							try {
								System.out.println("Total balance:" + ias.showBalance(Integer.parseInt(acctId)));
							} catch (NumberFormatException e2) {
								e2.printStackTrace();
							} catch (InvalidException e2) {
								e2.printStackTrace();
							}
							break;
						case "2":
							while(true) {
								System.out.println("Enter Account Id");
								acctId = sc.next();
								boolean isValidAcctId = its.validateAccountId(acctId);
								if (isValidAcctId) {
									break;
								} else {
									System.out.println("Invalid Account Id (Only digits are allowed)");
								}
							}
							while(true) { 
								System.out.println("Enter Amount");
								amount = sc.next();
								boolean isValidAmount = its.validateAmount(amount);
								if (isValidAmount) {
									break;
								} else {
									System.out.println("Invalid Amount (Only digits are allowed)");
								}
							}
							try {
								ias.withdraw(Double.parseDouble(amount),Integer.parseInt(acctId));
							} catch (NumberFormatException e1) {
								e1.printStackTrace();
							} catch (InvalidException e1) {
								System.out.println(e1.getMessage());
							}
							try {
								System.out.println("Total balance:" + ias.showBalance(Integer.parseInt(acctId)));
							} catch (NumberFormatException e2) {
								e2.printStackTrace();
							} catch (InvalidException e2) {
								e2.printStackTrace();
							}
							break;
						case "3":
							while(true) {
								System.out.println("Enter Account Id from which you want transfer from");
								sourceAcctId = sc.next();
								boolean isValidAcctId = its.validateAccountId(sourceAcctId);
								if (isValidAcctId) {
									break;
								} else {
									System.out.println("Invalid Account Id (Only digits are allowed)");
								}
							}
							while(true) {
								System.out.println("Enter Account Id to which you want transfer amount");
								destAcctId = sc.next();
								boolean isValidestAcctId = its.validateAccountId(destAcctId);
								if (isValidestAcctId) {
									break;
								} else {
									System.out.println("Invalid Account Id (Only digits are allowed)");
								}
							}
							while(true) { 
								System.out.println("Enter Amount");
								amount = sc.next();
								boolean isValidAmount = its.validateAmount(amount);
								if (isValidAmount) {
									break;
								} else {
									System.out.println("Invalid Amount (Only digits are allowed)");
								}
							}
							try {
								ias.fundTransfer(Integer.parseInt(sourceAcctId), Integer.parseInt(destAcctId), Double.parseDouble(amount));
							} catch (NumberFormatException e) {
								e.printStackTrace();
							} catch (InvalidException e) {
								System.out.println(e.getMessage());
							}
							break;
						case "4":
							while(true) {
								System.out.println("Enter Account Id");
								acctId = sc.next();
								boolean isValidAcctId = its.validateAccountId(acctId);
								if (isValidAcctId) {
									break;
								} else {
									System.out.println("Invalid Account Id (Only digits are allowed)");
								}
							}
							try {
								System.out.println("Total Balance :" + ias.showBalance(Integer.parseInt(acctId)));
							} catch (NumberFormatException e) {
								e.printStackTrace();
							} catch (InvalidException e) {
								System.out.println(e.getMessage());
							}							
							break;
						case "5": 
							while(true) {
								System.out.println("Enter Account Id");
								acctId = sc.next();
								boolean isValidAcctId = its.validateAccountId(acctId);
								if (isValidAcctId) {
									break;
								} else {
									System.out.println("Invalid Account Id  (Only digits are allowed)");
								}
							}
							ias.showTransaction(Integer.parseInt(acctId));
							break;
					}
					break;
			case "3":
					System.exit(0);
					break;
			}
		}
	}


}
