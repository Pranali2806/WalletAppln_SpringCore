package com.cg.exception;

public class InvalidException extends Exception {
	public InvalidException(String msg) {
		super(msg);
	}
}
