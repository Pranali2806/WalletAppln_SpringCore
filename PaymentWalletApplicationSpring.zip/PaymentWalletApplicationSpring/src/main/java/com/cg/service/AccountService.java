package com.cg.service;

import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;

import com.cg.entity.Account;
import com.cg.dao.AccountDao;
import com.cg.exception.InvalidException;

@Service("service")
public class AccountService implements IAccountService {
	AccountDao ad = new AccountDao();

	public boolean validateHolderName(String holderName) {
		if (holderName.matches(holderNamePattern)) {
			return true;
		} else {
			return false;
		}
	}

	public boolean validateHolderAddress(String holderAddress) {
		if (holderAddress.matches(holderAddressPattern)) {
			return true;
		} else {
			return false;
		}
	}

	public boolean validateHolderEmail(String holderEmail) {
		if (holderEmail.matches(holderEmailPattern)) {
			return true;
		} else {
			return false;
		}
	}

	public boolean validateHolderMobileNo(String holderMobileNo) {
		if (holderMobileNo.matches(mobileNumberPattern)) {
			return true;
		} else {
			return false;
		}
	}

	public void createAccount(Account acct) {
		ad.createAccount(acct);
	}

	public Map<Integer, Account> displayAccountDetails() {
		return ad.displayAccountDetails();
	}

	public void deposit(Double amount, int accountId) throws InvalidException {
		ad.deposit(amount, accountId);
	}

	public double showBalance(int accountId) throws InvalidException {
		return ad.showBalance(accountId);
	}

	public void withdraw(Double amount, int accountId) throws InvalidException {
		ad.withdraw(amount, accountId);

	}

	public void showTransaction(int accountId) {
		ad.showTransaction(accountId);
	}

	public void fundTransfer(int scourceAcctId, int destAcctId, double amount) throws InvalidException {
		ad.fundTransfer(scourceAcctId, destAcctId, amount);
	}

//	public void initializeDao(ApplicationContext ctx) {
//		// TODO Auto-generated method stub
//
//	}

}
