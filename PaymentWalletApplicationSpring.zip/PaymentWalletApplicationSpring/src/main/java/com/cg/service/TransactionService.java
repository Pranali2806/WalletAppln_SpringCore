package com.cg.service;

import com.cg.dao.AccountDao;

public class TransactionService implements ITransactionService {
	AccountDao ad = new AccountDao();
	@Override
	public boolean validateAmount(String amount) {
		if (amount.matches(accountIdPattern)) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean validateAccountId(String holderAccountId) {
		if (holderAccountId.matches(accountIdPattern)) {
			return true;
		} else {
			return false;
		}
	}

}
