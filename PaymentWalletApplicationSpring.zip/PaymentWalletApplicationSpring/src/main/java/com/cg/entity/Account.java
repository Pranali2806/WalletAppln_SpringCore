package com.cg.entity;

import org.springframework.stereotype.Component;

@Component("account")
public class Account {

	private int accountId;  
	private String holderName; 
	private String holderAddress; 
	private long holderMobileNumber; 
	private String holderEmail;
	private double MIN_BALANCE;
	private double balance;
	public Account(){	
	}
	public double getMIN_BALANCE() {
		return MIN_BALANCE;
	}
	public void setMIN_BALANCE(double mIN_BALANCE) {
		MIN_BALANCE = mIN_BALANCE;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public String getHolderName() {
		return holderName;
	}
	public void setHolderName(String holderName) {
		this.holderName = holderName;
	}
	public String getHolderAddress() {
		return holderAddress;
	}
	public void setHolderAddress(String holderAddress) {
		this.holderAddress = holderAddress;
	}
	public long getHolderMobileNumber() {
		return holderMobileNumber;
	}
	public void setHolderMobileNumber(long holderMobileNumber) {
		this.holderMobileNumber = holderMobileNumber;
	}
	public String getHolderEmail() {
		return holderEmail;
	}
	public void setHolderEmail(String holderEmail) {
		this.holderEmail = holderEmail;
	}
	@Override
	public String toString() {
		return "Account [accountId=" + accountId + ", holderName=" + holderName
				+ ", holderAddress=" + holderAddress + ", holderMobileNumber="
				+ holderMobileNumber + ", holderEmail=" + holderEmail + ", balance" + balance + " ] ";
	}
}

